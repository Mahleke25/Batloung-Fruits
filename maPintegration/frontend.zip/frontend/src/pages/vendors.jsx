import { useEffect, useState } from 'react';

const API = 'http://localhost:5000/api/vendors';
const blank = {
  VendorName: '',
  BusinessName: '',
  Telephone: '',
  Location: '',
  RegistrationDate: new Date().toISOString().slice(0, 10),
  Status: 'Active'
};

export default function Vendors() {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(blank);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const r = await fetch(API);
      if (!r.ok) throw new Error('Could not load vendors.');
      setRows(await r.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function save(e) {
    e.preventDefault();
    setError('');
    setMessage('');

    try {
      const r = await fetch(editing ? `${API}/${editing}` : API, {
        method: editing ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || 'Could not save vendor.');

      setForm(blank);
      setEditing(null);
      setMessage(editing ? 'Vendor updated.' : 'Vendor added.');
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  function edit(v) {
    setEditing(v.VendorID);
    setForm({
      VendorName: v.VendorName || '',
      BusinessName: v.BusinessName || '',
      Telephone: v.Telephone || '',
      Location: v.Location || '',
      RegistrationDate: String(v.RegistrationDate || '').slice(0, 10),
      Status: v.Status || 'Active'
    });
    setMessage('');
    setError('');
  }

  async function remove(v) {
    if (!window.confirm(`Delete vendor ${v.VendorName}?`)) return;
    try {
      const r = await fetch(`${API}/${v.VendorID}`, { method: 'DELETE' });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || 'Could not delete vendor.');
      setMessage('Vendor deleted.');
      await load();
    } catch (e) {
      setError(e.message);
    }
  }

  const visible = rows.filter(v => {
    const text = [v.VendorName, v.BusinessName, v.Telephone, v.Location]
      .join(' ').toLowerCase();
    return text.includes(search.toLowerCase()) &&
      (status === 'All' || v.Status === status);
  });

  const input = { padding: '10px', minWidth: '180px' };
  const cell = { padding: '10px', borderBottom: '1px solid #ddd' };

  return (
    <div style={{ padding: 25 }}>
      <h1>Vendor Management</h1>
      <p>Register and manage street vendors.</p>
      {message && <p style={{ color: 'green' }}>{message}</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <form onSubmit={save} style={{
        display: 'flex', flexWrap: 'wrap', gap: 10,
        padding: 18, background: 'white', borderRadius: 10
      }}>
        <h3 style={{ width: '100%' }}>{editing ? 'Edit Vendor' : 'Add Vendor'}</h3>
        <input style={input} name="VendorName" placeholder="Vendor name"
          value={form.VendorName} onChange={change} required />
        <input style={input} name="BusinessName" placeholder="Business name"
          value={form.BusinessName} onChange={change} required />
        <input style={input} name="Telephone" placeholder="Telephone"
          value={form.Telephone} onChange={change} />
        <input style={input} name="Location" placeholder="Location"
          value={form.Location} onChange={change} required />
        <input style={input} type="date" name="RegistrationDate"
          value={form.RegistrationDate} onChange={change} required />
        <select style={input} name="Status" value={form.Status} onChange={change}>
          <option>Active</option><option>Inactive</option>
        </select>
        <button type="submit">{editing ? 'Save Changes' : 'Add Vendor'}</button>
        {editing && <button type="button" onClick={() => {
          setEditing(null); setForm(blank);
        }}>Cancel</button>}
      </form>

      <div style={{ display: 'flex', gap: 10, margin: '20px 0', flexWrap: 'wrap' }}>
        <input style={input} placeholder="Search vendors..."
          value={search} onChange={e => setSearch(e.target.value)} />
        <select style={input} value={status} onChange={e => setStatus(e.target.value)}>
          <option>All</option><option>Active</option><option>Inactive</option>
        </select>
      </div>

      {loading ? <p>Loading vendors...</p> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', background: 'white' }}>
            <thead><tr>{['ID','Vendor','Business','Telephone','Location','Registration Date','Status','Actions'].map(x =>
              <th key={x} style={cell}>{x}</th>)}</tr></thead>
            <tbody>
              {visible.map(v => <tr key={v.VendorID}>
                <td style={cell}>{v.VendorID}</td>
                <td style={cell}>{v.VendorName}</td>
                <td style={cell}>{v.BusinessName}</td>
                <td style={cell}>{v.Telephone}</td>
                <td style={cell}>{v.Location}</td>
                <td style={cell}>{String(v.RegistrationDate || '').slice(0,10)}</td>
                <td style={cell}>{v.Status}</td>
                <td style={cell}>
                  <button onClick={() => edit(v)}>Edit</button>
                  <button style={{ marginLeft: 5 }} onClick={() => remove(v)}>Delete</button>
                </td>
              </tr>)}
              {visible.length === 0 && <tr><td style={cell} colSpan="8">No vendors found.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <p>Showing {visible.length} of {rows.length} vendors.</p>
    </div>
  );
}